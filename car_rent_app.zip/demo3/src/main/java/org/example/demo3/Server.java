package org.example.demo3;

import java.net.ServerSocket;
import java.net.Socket;


public class Server {
    public static void main(String[] args) {
        try{
            ServerSocket server = new ServerSocket(6666);// 65536
            int id = 1;
            while (true){
                Socket socket = server.accept();
                System.out.println("Client #"+ id +" connected successfully");
                ServerThread clients = new ServerThread(socket, id);
                id++;
                clients.start();
            }



        }catch (Exception e){
            e.printStackTrace();
        }
    }
}