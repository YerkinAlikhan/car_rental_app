package org.example.demo3;

public class Car {
    private int CarId;             //id машины
    private String brand;       // Марка машины
    private String model;       // Модель машины
    private int year;           // Год выпуска машины
    private double pricePerDay; // Стоимость аренды в день
    private boolean rented;     // Признак, арендована ли машина


    public Car(int CarId,String brand, String model, int year, double pricePerDay) {
        this.CarId=CarId;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.pricePerDay = pricePerDay;
        this.rented = false; // По умолчанию машина не арендована
    }

    public Car( int carId, String brand, String model, int year,double pricePerDay, boolean rented) {
        this.brand = brand;
        CarId = carId;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.rented = rented;
        this.year = year;
    }

    public Car() {

    }

    // Методы класса
    // Геттеры и сеттеры для доступа к полям

    public int getId() {return CarId;}

    public void setId(int id) {this.CarId = CarId;}

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(double pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public boolean isRented() {
        return rented;
    }

    public void setRented(boolean rented) {
        this.rented = rented;
    }

    // Метод для аренды машины
    public void rent() {
        this.rented = true;
    }

    // Метод для возврата машины
    public void returnCar() {
        this.rented = false;
    }

    // Метод для проверки доступности машины (не арендована ли уже)
    public boolean isAvailable() {
        return !this.rented;
    }

    // Метод для получения информации о машине в виде строки

    @Override
    public String toString() {
        return
                 CarId +" "+
                  brand +
                         " "+model  +
                         " "+year +
                         " "+pricePerDay +
                         " "+rented;
    }
}

