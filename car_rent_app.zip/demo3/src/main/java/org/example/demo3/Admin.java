package org.example.demo3;

public class Admin {
private String login;
private String password;

}
