package org.example.demo3;

import javafx.geometry.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;


public class Hello extends Application {


    private static final String CORRECT_USERNAME = "ad";
    private static final String CORRECT_PASSWORD = "111";

    TextField firstNameField = new TextField();
    TextField lastNameField = new TextField();
    TextField phoneNumberField = new TextField();
    Button addUser = new Button("Add user");
    Button client =new Button("Client");
    Button admin=new Button("Admin");
    TextField usernameField = new TextField();
    PasswordField passwordField = new PasswordField();
    TextField emailField = new TextField();
    Button loginButton = new Button("Login");
    Button exitButton = new Button("Exit");
     ObjectOutputStream outputStream;
     Object date;

    TextArea area = new TextArea();
     TextField tf1 = new TextField();
     TextField tf2 = new TextField();
     TextField tf3 = new TextField();
     TextField tf4 = new TextField();
     TextField tf5 = new TextField();

     TextField day=new TextField();
     TextField totalcost =new TextField();

    Button payButton = new Button("Pay");
    Button addCarButton = new Button("Add Car");
    Button insertCarButton = new Button("Insert Car");
    Button deleteCarButton = new Button("Delete Car");
    Button listAllCarButton = new Button("List All Cars");
    Button updateCarButton = new Button("Update Car");
    Button update=new Button("Update Car");
    Button deleteCar=new Button("Delete Car");
    Button deleteCustomer =new Button("Delete Customer");
    Button listAllCustomerButton = new Button("List All Customers");
    Button ListAllCustomerButtonExit = new Button(" Exit ");
    Button deleteCustomerButton=new Button("Delete");
    Button rentCarButton =new Button("Rent car");
    Button rentCar =new Button("Next");
    Button pay=new Button("Pay");
    Button exitPay=new Button("Exit");
    Button ListAllCarButtonExitAdmin = new Button("Exit");
    Button ListAllCarButtonExitClient = new Button("Exit");
    Button exitAll = new Button("Exit");
    Button listAllCarButtonClient = new Button("List All Cars");
    Button returnCarButton=new Button("Return Car");
    Button returnCarButtonReturned=new Button("Return");


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        try {
            Socket socket = new Socket("127.0.0.1", 6666);
            outputStream = new ObjectOutputStream(socket.getOutputStream()); // Присваиваем здесь
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(System.in));
            String message = "";
        } catch (Exception e) {
            e.printStackTrace();
        }
       DBManager.connect();
        primaryStage.setTitle("Rent");


        Label firstName = new Label("First Name:");
        Label lastName = new Label("Last Name:");
        Label phoneNumber=new Label("Phone Number:");
        Label email=new Label("Email:");

        Label usernameLabel = new Label("Username:");
        Label passwordLabel = new Label("Password:");
        Label resultLabel = new Label();
        Label tf1Label = new Label("ID:");
        Label tf2Label = new Label("Brand:");
        Label tf3Label = new Label("Model:");
        Label tf4Label = new Label("Year:");
        Label tf5Label = new Label("Price Per Day:");
        Label CarIdLabel = new Label("Car id");
        Label howMuchLabel = new Label();
        Label rentCarLabel = new Label("How many days");
        Label payLabel = new Label("Car is rented");

        tf1.setText("1");
        VBox admBox=new VBox();

        VBox result=new VBox();
        admBox.getChildren().addAll(tf1Label, tf1
        );

        admBox.getChildren().addAll(tf2Label, tf2
        );
        admBox.getChildren().addAll(tf3Label, tf3
        );
        admBox.getChildren().addAll(tf4Label, tf4
        );
        admBox.getChildren().addAll(tf5Label, tf5
        );



        String buttonStyle = "-fx-background-color: #808080;"; // Grey color
        admin.setStyle(buttonStyle);
        client.setStyle(buttonStyle);
        addUser.setStyle(buttonStyle);
        client.setStyle(buttonStyle);
        admin.setStyle(buttonStyle);
        loginButton.setStyle(buttonStyle);
        exitButton.setStyle(buttonStyle);
        payButton.setStyle(buttonStyle);
        addCarButton.setStyle(buttonStyle);
        insertCarButton.setStyle(buttonStyle);
        deleteCarButton.setStyle(buttonStyle);
        listAllCarButton.setStyle(buttonStyle);
        updateCarButton.setStyle(buttonStyle);
        update.setStyle(buttonStyle);
        deleteCar.setStyle(buttonStyle);
        deleteCustomer.setStyle(buttonStyle);
        listAllCustomerButton.setStyle(buttonStyle);
        ListAllCustomerButtonExit.setStyle(buttonStyle);
        ListAllCarButtonExitAdmin.setStyle(buttonStyle);
        ListAllCarButtonExitClient.setStyle(buttonStyle);
        exitAll.setStyle(buttonStyle);
        listAllCarButtonClient.setStyle(buttonStyle);
        returnCarButton.setStyle(buttonStyle);
        returnCarButtonReturned.setStyle(buttonStyle);

        HBox hbox = new HBox(admin, client);
        hbox.setPadding(new Insets(15, 12, 15, 12));
        hbox.setSpacing(10);
        hbox.setAlignment(Pos.CENTER);
        hbox.setId("admin_button");
        if (!hbox.getChildren().contains(admin)) {
            hbox.getChildren().add(admin);
        }
        if (!hbox.getChildren().contains(client)) {
            hbox.getChildren().add(client);
        }
        hbox.setAlignment(Pos.CENTER);
        result.setAlignment(Pos.CENTER);
        result.getChildren().clear(); // Clear any existing children
        result.getChildren().addAll(hbox);
        HBox carButtonHBox = new HBox(addCarButton,updateCarButton,deleteCarButton,listAllCarButton);
        HBox clientButtonHBox=new HBox(deleteCustomer,listAllCustomerButton);
        carButtonHBox.setAlignment(Pos.CENTER);
        clientButtonHBox.setAlignment(Pos.CENTER);
        VBox carButtonBox = new VBox(carButtonHBox);
        VBox clientBox = new VBox(firstName, firstNameField, lastName, lastNameField, phoneNumber, phoneNumberField, email, emailField, addUser);

        exitAll.setOnAction(e -> {
            result.getChildren().clear();
            result.getChildren().addAll(admin, client);
        });

        admin.setOnAction(e -> {
            hbox.getChildren().removeAll(admin, client);
            result.getChildren().clear(); // Очищаем все дочерние элементы
            result.getChildren().addAll(usernameLabel, usernameField, passwordLabel, passwordField, loginButton, resultLabel, exitButton);
        });

        client.setOnAction(e -> {
            result.getChildren().clear(); // Очищаем все дочерние элементы
            result.getChildren().addAll(clientBox, exitButton);
        });

        addUser.setOnAction(e -> {
            insert();
            result.getChildren().clear(); // Очищаем все дочерние элементы
            result.getChildren().addAll(listAllCarButtonClient, rentCarButton,returnCarButton, exitAll);
        });


        exitButton.setOnAction(e -> {
            result.getChildren().clear();
            hbox.getChildren().clear();
            hbox.getChildren().addAll(admin, client);
            result.setAlignment(Pos.CENTER);
            result.getChildren().addAll(hbox);
        });


        loginButton.setOnAction(event -> {
            result.getChildren().clear();
            String enteredUsername = usernameField.getText();
            String enteredPassword = passwordField.getText();
            if (enteredUsername.equals(CORRECT_USERNAME) && enteredPassword.equals(CORRECT_PASSWORD)) {
                resultLabel.setText("Login successful!");
                result.getChildren().addAll(carButtonBox,clientButtonHBox,exitAll);

                try {
                    Date date = new Date();
                    outputStream.writeObject(enteredUsername + " " + " at " + date + ": Admin logged");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else {
                resultLabel.setText("Login failed. Please check your credentials.");
            }
        });

        insertCarButton.setOnAction(e->{AddCar();
            result.getChildren().clear();
        result.getChildren().addAll(carButtonBox,clientButtonHBox,exitAll);
        });
        update.setOnAction(e->{updateCar();
            result.getChildren().clear();
        result.getChildren().addAll(carButtonBox,clientButtonHBox,exitAll);
        });

        deleteCar.setOnAction(e->{DeleteCar();
            result.getChildren().clear();
        result.getChildren().addAll(carButtonBox,clientButtonHBox,exitAll);
        });

        deleteCustomerButton.setOnAction(e->{DeleteCustomer();
            result.getChildren().clear();
            result.getChildren().addAll(carButtonBox,clientButtonHBox,exitAll);
        });
        deleteCustomer.setOnAction(e->{
            result.getChildren().clear();
            result.getChildren().addAll(tf1);
            result.getChildren().add(deleteCustomerButton);
        });

        ListAllCustomerButtonExit.setOnAction(e->{
            result.getChildren().clear();
            result.getChildren().addAll(carButtonBox,clientButtonHBox,exitAll);
        });
        ListAllCarButtonExitAdmin.setOnAction(e->{
            result.getChildren().clear();
            result.getChildren().addAll(carButtonBox,clientButtonHBox,exitAll);
        });


        addCarButton.setOnAction(e->{
            result.getChildren().clear();
            admBox.getChildren().addAll(insertCarButton);
            result.getChildren().addAll(admBox);
        });


        updateCarButton.setOnAction(e->{
            result.getChildren().clear();
            admBox.getChildren().add(update);
            result.getChildren().addAll(admBox);
        });

        deleteCarButton.setOnAction(e->{
            result.getChildren().clear();
            result.getChildren().addAll(tf1);
            result.getChildren().add(deleteCar);
        });

        listAllCarButton.setOnAction(e->{
            result.getChildren().clear();
            area.clear();
            ArrayList<Car> cars = new ArrayList<>();
            cars=DBManager.listAllCar();
            for (int i = 0; i < cars.size(); i++) {
                area.appendText((cars.get(i).toString()+"\n"));
            }
            result.getChildren().addAll(area);
            result.getChildren().addAll(ListAllCarButtonExitAdmin);

        });

        listAllCarButtonClient.setOnAction(e->{
            result.getChildren().clear();
            area.clear();
            ArrayList<Car> cars = new ArrayList<>();
            cars=DBManager.listAllCar();
            for (int i = 0; i < cars.size(); i++) {
                area.appendText((cars.get(i).toString()+"\n"));
            }
            result.getChildren().addAll(area);
            result.getChildren().addAll(ListAllCarButtonExitClient);

        });

        ListAllCarButtonExitClient.setOnAction(e->{
            result.getChildren().clear();
            result.getChildren().addAll(listAllCarButton,rentCarButton,returnCarButton,exitAll);
        });

        listAllCustomerButton.setOnAction(e->{
            result.getChildren().clear();
            area.clear();
            ArrayList<Customer> customers = new ArrayList<>();
            customers=DBManager.getAllCustomers();
            result.getChildren().removeAll(carButtonBox,clientButtonHBox);
            for (int i = 0; i < customers.size(); i++) {
                area.appendText((customers.get(i).toString()+"\n"));

            }
            result.getChildren().addAll(area);
            result.getChildren().addAll(ListAllCustomerButtonExit);
        });

        rentCarButton.setOnAction(e->{
            result.getChildren().clear();
            result.getChildren().addAll(CarIdLabel,day);
            result.getChildren().addAll(rentCar);
        });

        rentCar.setOnAction(e->{
            result.getChildren().clear();

            result.getChildren().addAll(rentCarLabel,totalcost);
            result.getChildren().addAll(payButton);
        });

        payButton.setOnAction(e->{
            result.getChildren().clear();

            howMuchLabel.setText(String.valueOf(TotalCost()));

            result.getChildren().add(howMuchLabel);
            result.getChildren().addAll(pay,exitPay);
        });
        exitPay.setOnAction(e->{
            result.getChildren().clear();
            result.getChildren().addAll(listAllCarButtonClient,rentCarButton,returnCarButton);
        });
        pay.setOnAction(e->{
            result.getChildren().clear();

            DBManager.updateCarRent(Integer.parseInt(day.getText()));
            result.getChildren().addAll(payLabel,exitPay);

        });

        returnCarButton.setOnAction(e->{
            result.getChildren().clear();
            Label returnLabel = new Label("Enter car id");
            day.clear();
            result.getChildren().addAll(returnLabel,day,returnCarButtonReturned);


        });

        returnCarButtonReturned.setOnAction(e->{
            DBManager.returnCarRent(Integer.parseInt(day.getText()));
            result.getChildren().clear();
            Label carReturnedLabel = new Label("Car Returned");
            result.getChildren().add(carReturnedLabel);
            result.getChildren().addAll(exitPay);
        });


        result.setStyle("-fx-background-color: #cfcfb8");
        Scene scene = new Scene(result, 400, 500);
        primaryStage.setScene(scene);
        scene.setFill(Color.BEIGE);
        result.getChildren().removeAll();


        primaryStage.setTitle("Rent car App");


        primaryStage.show();
    }
    private void insert() {
        String LastName = lastNameField.getText();
        String firstName = firstNameField.getText();
        String phoneNumber = phoneNumberField.getText();
        String email = emailField.getText();
        Customer customer = new Customer(firstName, LastName, phoneNumber, email);
        DBManager.addCustomer(customer);
        try {
            Date date = new Date();
            outputStream.writeObject(LastName + " " + firstName + " at " + date + ": registered");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private void AddCar(){
        int CarId= Integer.parseInt(tf1.getText());
        String brand = tf2.getText();
        String model = tf3.getText();
        int year = Integer.parseInt(tf4.getText());
        double pricePerDay = Double.parseDouble(tf5.getText());

        Car car=new Car(CarId,brand,model,year,pricePerDay);
        DBManager.addCar(car);
        try {
            Date date = new Date();
            outputStream.writeObject(  " At " + date + ": added new car");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private void updateCar(){
        int CarId= Integer.parseInt(tf1.getText());
        String brand = tf2.getText();
        String model = tf3.getText();
        int year = Integer.parseInt(tf4.getText());
        double pricePerDay = Double.parseDouble(tf5.getText());
        Car car=new Car(CarId,brand,model,year,pricePerDay);
        DBManager.updateCar(car);
        try {
            Date date = new Date();
            outputStream.writeObject(  " At " + date + ": updated car with id "+CarId);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void DeleteCar(){
        int CarId= Integer.parseInt(tf1.getText());
        DBManager.deleteCar(CarId);
        try {
            Date date = new Date();
            outputStream.writeObject(  " At " + date + ": deleted car with id "+CarId);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private void DeleteCustomer(){
        int clientId= Integer.parseInt(tf1.getText());
        DBManager.deleteCustomer(clientId);
        try {
            Date date = new Date();
            outputStream.writeObject(  " At " + date + ": deleted client with id "+clientId);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private int TotalCost(){
        int total=0;
        int id= Integer.parseInt(day.getText());
        int perDay= DBManager.cost(id);
        total=Integer.parseInt(totalcost.getText())*perDay;
        try {
            Date date = new Date();
            outputStream.writeObject(  " At " + date + ": rented "+id+" car for "+Integer.parseInt(totalcost.getText())+" days");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return total;

    }

}
