package org.example.demo3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DBManager {
    private static final String url = "jdbc:postgresql://localhost/Project";
    private static final String user = "postgres";
    private static final String password = "clashofcl";
    private static Connection connection;

    public DBManager() {
    }

    public static void connect(){
        try{
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connection success!");
        }catch(Exception e){
            System.out.println("Connection error!");
            e.printStackTrace();
        }
    }

    public static void addCar(Car car) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO public.car " +
                    "(carId, brand, model, year, pricePerDay, rented) VALUES (?, ?, ?, ?, ?, ?)");
            statement.setInt(1, car.getId());
            statement.setString(2, car.getBrand());
            statement.setString(3, car.getModel());
            statement.setInt(4, car.getYear());
            statement.setDouble(5, car.getPricePerDay());
            statement.setBoolean(6, car.isRented());
            statement.executeUpdate();
            statement.close();
        } catch (Exception e) {
            System.out.println("Error adding car!");
            e.printStackTrace();
        }
    }

    public static void deleteCar(int carId) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM public.car WHERE carId = ?");
            statement.setInt(1, carId);
            statement.executeUpdate();
            statement.close();
        } catch (Exception e) {
            System.out.println("Error deleting car!");
            e.printStackTrace();
        }
    }

    public static void updateCar(Car car) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE public.car " +
                    "SET brand=?, model=?, year=?, pricePerDay=? WHERE carId=?");
            statement.setString(1, car.getBrand());
            statement.setString(2, car.getModel());
            statement.setInt(3, car.getYear());
            statement.setDouble(4, car.getPricePerDay());


            statement.setInt(5, car.getId());
            statement.executeUpdate();
            statement.close();
        } catch (Exception e) {
            System.out.println("Error updating car!");
            e.printStackTrace();
        }
    }

    public static ArrayList<Car> listAllCar() {
        ArrayList<Car> cars = new ArrayList<>();

        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM public.car");
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                int id = result.getInt("carId");
                String brand = result.getString("brand");
                String model = result.getString("model");
                int year = result.getInt("year");
                double pricePerDay = result.getDouble("pricePerDay");
                boolean rented = result.getBoolean("rented");


                cars.add(new Car(id, brand, model, year, pricePerDay,rented));

            }
            statement.close();
        } catch (Exception e) {
            System.out.println("Error listing all cars!");
            e.printStackTrace();
        }

        return cars;
    }



    public static ArrayList<Customer> getAllCustomers(){
        ArrayList<Customer> customers = new ArrayList<>();

        try{
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM public.Customer");
            ResultSet result = statement.executeQuery();

            while(result.next()){
                int clientId = result.getInt("clientId");
                String firstName = result.getString("firstName");
                String lastName = result.getString("lastName");
                String phoneNumber = result.getString("phoneNumber");
                String email = result.getString("email");

                Customer customer = new Customer(clientId, firstName, lastName, phoneNumber, email);
                customers.add(customer);
            }
            statement.close();
        }catch(Exception e){
            System.out.println("Error fetching customers!");
            e.printStackTrace();
        }

        return customers;
    }

    public static void deleteCustomer(int customerId) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM public.Customer WHERE clientId = ?");
            statement.setInt(1, customerId);
            statement.executeUpdate();
            statement.close();
        } catch (Exception e) {
            System.out.println("Error deleting customer!");
            e.printStackTrace();
        }
    }

    public static void updateCustomer(Customer customer) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE public.Customer " +
                    "SET firstName=?, lastName=?, phoneNumber=?, email=? WHERE clientId=?");
            statement.setString(1, customer.getFirstName());
            statement.setString(2, customer.getLastName());
            statement.setString(3, customer.getPhoneNumber());
            statement.setString(4, customer.getEmail());
            statement.setInt(5, customer.getClientId());
            statement.executeUpdate();
            statement.close();
        } catch (Exception e) {
            System.out.println("Error updating customer!");
            e.printStackTrace();
        }
    }


    public static void addCustomer(Customer customer) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO public.Customer " +
                    "(firstName, lastName, phoneNumber, email) VALUES (?, ?, ?, ?)");
            statement.setString(1, customer.getFirstName());
            statement.setString(2, customer.getLastName());
            statement.setString(3, customer.getPhoneNumber());
            statement.setString(4, customer.getEmail());
            statement.executeUpdate();
            statement.close();
        } catch (Exception e) {
            System.out.println("Error adding customer!");
            e.printStackTrace();
        }
    }

    public static int cost(int id){
        int cost = 0;
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT pricePerDay FROM public.car WHERE carId = ?");
            statement.setLong(1, id);
            ResultSet result = statement.executeQuery();
            if (result.next()) { // Move the cursor to the first row
                cost = result.getInt("pricePerDay");
            }
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cost;
    }

    public static void updateCarRent(int carId) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE public.car " +
                    "SET rented=? WHERE carId=?");
            statement.setBoolean(1, true); // Use setBoolean() for boolean values
            statement.setInt(2, carId);
            statement.executeUpdate();
            statement.close();
        } catch (Exception e) {
            System.out.println("Error updating car!");
            e.printStackTrace();
        }
    }

    public static void returnCarRent(int carId) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE public.car " +
                    "SET rented=? WHERE carId=?");
            statement.setBoolean(1, false); // Use setBoolean() for boolean values
            statement.setInt(2, carId);
            statement.executeUpdate();
            statement.close();
        } catch (Exception e) {
            System.out.println("Error updating car!");
            e.printStackTrace();
        }
    }


}

