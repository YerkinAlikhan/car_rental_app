package org.example.demo3;

import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class ServerThread extends Thread{
    private Socket socket;
    private int id;

    public ServerThread(Socket socket, int id) {
        this.socket = socket;
        this.id = id;
    }

    public void run(){
        try{
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
            PrintWriter fileWriter = new PrintWriter(new FileWriter("output.txt", true)); // true for appending

            String s = "";
            while ((s = (String)inputStream.readObject())!=null ){
                System.out.println(s);
                fileWriter.println(s); // Write to file
                fileWriter.flush();
            }
            fileWriter.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
